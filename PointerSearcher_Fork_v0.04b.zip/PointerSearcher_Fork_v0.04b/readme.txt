﻿   __________.__                 __   ________                 __  .__
   \______   \  | _____    ____ |  | _\______ \   ____ _____ _/  |_|  |__
    |    |  _/  | \__  \ _/ ___\|  |/ /|    |  \_/ __ \\__  \\   __\  |  \
    |    |   \  |__/ __ \\  \___|    < |    `   \  ___/ / __ \|  | |   \  \
    |______  /____(____  /\___  >__|_ \|______  /\___  >____  /__| |___|  /
           \/          \/     \/     \/       \/     \/     \/          \/


                           PointerSearcher 0.04b
          a fork of https://github.com/Takumi4685/PointerSearcher


            v0.04a : added option to Load/Save used ProjectFiles
            v0.04b : added option to export Results to Code List

             Many Thanks to Takumi4685 for the original project.
                Without him this fork would not be possible.